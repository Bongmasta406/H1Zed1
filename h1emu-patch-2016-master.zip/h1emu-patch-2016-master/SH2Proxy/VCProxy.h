// proxydll.h
#pragma once

// regular functions
void InitInstance(HANDLE hModule);
void ExitInstance(void);